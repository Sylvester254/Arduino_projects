Released Firmware
=================

It is recommended to use the lastest version of firmware.

## ESP-WROOM-02 Series

- v2.2.1.0 [ESP8266-IDF-AT_V2.2.1.0.zip](https://download.espressif.com/esp_at/firmware/ESP8266/ESP8266-IDF-AT_V2.2.1.0.zip) (Recommended)
- v2.2.0.0 [ESP8266-IDF-AT_V2.2.0.0.zip](https://download.espressif.com/esp_at/firmware/ESP8266/ESP8266-IDF-AT_V2.2.0.0.zip)
- v2.1.0.0 [ESP8266-IDF-AT_V2.1.0.0.zip](https://download.espressif.com/esp_at/firmware/ESP8266/ESP8266-IDF-AT_V2.1.0.0.zip)
- v2.0.0.0 [ESP8266-IDF-AT_V2.0.0.0.zip](https://download.espressif.com/esp_at/firmware/ESP8266/ESP8266-IDF-AT_V2.0_0.zip)
