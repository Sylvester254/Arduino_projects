Tencent Cloud IoT AT Command Set
================================

Please refer to :link_to_translation:`zh_CN:[Chinese version]`. The English version is not provided since the firmware and commands are applicable to the Chinese market (Tencent). 