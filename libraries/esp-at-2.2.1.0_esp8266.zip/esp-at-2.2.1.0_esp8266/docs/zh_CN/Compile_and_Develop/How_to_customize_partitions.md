如何自定义分区
===========================

See: `/docs/en/Compile_and_Develop/How_to_customize_partitions.md`