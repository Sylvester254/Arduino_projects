如何创建默认出厂参数 bin 文件
===================================

See: `/docs/en/Compile_and_Develop/How_to_create_factory_parameter_bin.md`