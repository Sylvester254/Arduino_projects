#ifndef SDIO_CONFIG_H_
#define SDIO_CONFIG_H_

#define TARGET_ESP32  1

#endif /* SDIO_CONFIG_H_ */
