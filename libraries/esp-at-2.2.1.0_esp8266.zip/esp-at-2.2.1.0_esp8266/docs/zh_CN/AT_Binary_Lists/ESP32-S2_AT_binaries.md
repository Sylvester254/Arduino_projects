发布的固件
=================

推荐下载最新版本的固件。

## ESP32-S2-WROOM Series

- v2.1.0.0 [ESP32-S2-WROOM_AT_Bin_V2.1.0.0.zip](https://download.espressif.com/esp_at/firmware/ESP32S2/ESP32-S2-WROOM/ESP32-S2-WROOM_AT_Bin_V2.1.0.0.zip)（推荐）

## ESP32-S2-WROVER Series

- v2.1.0.0 [ESP32-S2-WROVER_AT_Bin_V2.1.0.0.zip](https://download.espressif.com/esp_at/firmware/ESP32S2/ESP32-S2-WROVER/ESP32-S2-WROVER_AT_Bin_V2.1.0.0.zip)（推荐）

## ESP32-S2-SOLO Series

- v2.1.0.0 [ESP32-S2-SOLO_AT_Bin_V2.1.0.0.zip](https://download.espressif.com/esp_at/firmware/ESP32S2/ESP32-S2-SOLO/ESP32-S2-SOLO_AT_Bin_V2.1.0.0.zip)（推荐）

## ESP32-S2-MINI Series

- v2.1.0.0 [ESP32-S2-MINI_AT_Bin_V2.1.0.0.zip](https://download.espressif.com/esp_at/firmware/ESP32S2/ESP32-S2-MINI/ESP32-S2-MINI_AT_Bin_V2.1.0.0.zip)（推荐）
