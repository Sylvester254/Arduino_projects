#pragma once


#ifdef __cplusplus
extern "C" {
#endif

//MVA leave only necessary definitions

typedef void * QueueHandle_t;


#ifdef __cplusplus
}
#endif

