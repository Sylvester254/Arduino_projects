腾讯云 IoT AT 固件
===========================
 
ESP8266
--------

  - ESP8266-WROOM-02 系列
    
    - `QCloud_AT_ESP8266_v2.2.0 <http://download.espressif.com/esp_at/firmware/QCloud_AT_IoT/ESP8266/QCloud_AT_ESP8266_v2.2.0.zip>`_
    - `QCloud_AT_ESP8266_v2.1.1 <http://download.espressif.com/esp_at/firmware/QCloud_AT_IoT/ESP8266/QCloud_AT_ESP8266_v2.1.1.zip>`_

